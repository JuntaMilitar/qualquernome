import React, { useEffect, useState } from 'react';
import { Monitor, Clock, Users, AlertCircle, WifiOff } from 'lucide-react';
import { Ticket } from '../types';

interface DisplayProps {
  currentTicket: Ticket | null;
  waitingTickets: Ticket[];
  isConnected: boolean;
}

export const Display: React.FC<DisplayProps> = ({ currentTicket, waitingTickets, isConnected }) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const priorityWaiting = waitingTickets.filter(t => t.type === 'priority');
  const normalWaiting = waitingTickets.filter(t => t.type === 'normal');
  const nextTickets = [...priorityWaiting, ...normalWaiting].slice(0, 5);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-blue-900 text-white p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <Monitor className="w-8 h-8" />
            <h1 className="text-3xl font-bold">Painel de Chamadas</h1>
            {!isConnected && (
              <div className="flex items-center space-x-2 text-red-400">
                <WifiOff className="w-6 h-6" />
                <span className="text-sm">Desconectado</span>
              </div>
            )}
          </div>
          <div className="text-right">
            <div className="text-2xl font-mono">
              {currentTime.toLocaleTimeString()}
            </div>
            <div className="text-sm opacity-75">
              {currentTime.toLocaleDateString()}
            </div>
          </div>
        </div>

        {/* Connection Warning */}
        {!isConnected && (
          <div className="bg-red-500/20 border border-red-500/50 rounded-2xl p-6 mb-8 text-center">
            <div className="flex items-center justify-center space-x-2 text-red-300">
              <WifiOff className="w-6 h-6" />
              <span className="text-lg font-semibold">Sem conexão com o servidor</span>
            </div>
            <p className="text-sm opacity-75 mt-2">
              As informações podem estar desatualizadas
            </p>
          </div>
        )}

        {/* Current Ticket */}
        <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-12 mb-8 text-center">
          <h2 className="text-2xl font-semibold mb-4 opacity-90">
            Senha Atual
          </h2>
          {currentTicket ? (
            <div className="space-y-4">
              <div className="text-8xl font-bold text-yellow-400 animate-pulse">
                {currentTicket.number}
              </div>
              <div className="flex items-center justify-center space-x-4 text-lg">
                <span className={`px-4 py-2 rounded-full ${
                  currentTicket.type === 'priority' 
                    ? 'bg-amber-500/20 text-amber-300' 
                    : 'bg-blue-500/20 text-blue-300'
                }`}>
                  {currentTicket.type === 'priority' ? 'Prioritário' : 'Normal'}
                </span>
                <span className="opacity-75">
                  Chamada às {currentTicket.calledAt?.toLocaleTimeString()}
                </span>
              </div>
            </div>
          ) : (
            <div className="text-4xl font-semibold opacity-50">
              Aguardando próxima senha
            </div>
          )}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Queue Stats */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6">
            <h3 className="text-xl font-semibold mb-6 flex items-center">
              <Users className="w-6 h-6 mr-2" />
              Status da Fila
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-amber-500/20 rounded-xl p-4 text-center">
                <div className="text-3xl font-bold text-amber-300">
                  {priorityWaiting.length}
                </div>
                <div className="text-sm opacity-75">Prioritárias</div>
              </div>
              <div className="bg-blue-500/20 rounded-xl p-4 text-center">
                <div className="text-3xl font-bold text-blue-300">
                  {normalWaiting.length}
                </div>
                <div className="text-sm opacity-75">Normais</div>
              </div>
            </div>
          </div>

          {/* Next Tickets */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6">
            <h3 className="text-xl font-semibold mb-6 flex items-center">
              <Clock className="w-6 h-6 mr-2" />
              Próximas Senhas
            </h3>
            {nextTickets.length > 0 ? (
              <div className="space-y-3">
                {nextTickets.map((ticket, index) => (
                  <div
                    key={ticket.id}
                    className={`flex items-center justify-between p-3 rounded-lg ${
                      index === 0 ? 'bg-yellow-500/20' : 'bg-white/5'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="font-bold text-lg">
                        {ticket.number}
                      </span>
                      <span className={`px-2 py-1 rounded text-xs ${
                        ticket.type === 'priority'
                          ? 'bg-amber-500/30 text-amber-200'
                          : 'bg-blue-500/30 text-blue-200'
                      }`}>
                        {ticket.type === 'priority' ? 'P' : 'N'}
                      </span>
                    </div>
                    <span className="text-sm opacity-75">
                      {ticket.createdAt.toLocaleTimeString()}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 opacity-50">
                <AlertCircle className="w-12 h-12 mx-auto mb-2" />
                <p>Nenhuma senha na fila</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};