import React, { useState } from 'react';
import { Users, Clock, Ticket as TicketIcon, AlertCircle } from 'lucide-react';
import { Ticket } from '../types';

interface TicketGeneratorProps {
  onGenerateTicket: (type: 'normal' | 'priority') => Promise<Ticket>;
  isConnected: boolean;
}

export const TicketGenerator: React.FC<TicketGeneratorProps> = ({ onGenerateTicket, isConnected }) => {
  const [lastTicket, setLastTicket] = useState<Ticket | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateTicket = async (type: 'normal' | 'priority') => {
    if (!isConnected) {
      setError('Sem conexão com o servidor');
      return;
    }

    setIsGenerating(true);
    setError(null);
    
    try {
      const ticket = await onGenerateTicket(type);
      setLastTicket(ticket);
    } catch (err) {
      setError('Erro ao gerar senha. Tente novamente.');
      console.error('Erro ao gerar senha:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            Gerador de Senhas
          </h1>
          <p className="text-lg text-gray-600">
            Retire sua senha e aguarde ser chamado
          </p>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-6 flex items-center space-x-2">
            <AlertCircle className="w-5 h-5" />
            <span>{error}</span>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-blue-600" />
              </div>
              <h2 className="text-2xl font-semibold text-gray-800 mb-2">
                Atendimento Normal
              </h2>
              <p className="text-gray-600">
                Para serviços regulares e consultas gerais
              </p>
            </div>
            <button
              onClick={() => handleGenerateTicket('normal')}
              disabled={isGenerating || !isConnected}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 px-6 rounded-xl transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? 'Gerando...' : 'Retirar Senha Normal'}
            </button>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-amber-600" />
              </div>
              <h2 className="text-2xl font-semibold text-gray-800 mb-2">
                Atendimento Prioritário
              </h2>
              <p className="text-gray-600">
                Para idosos, gestantes e pessoas com deficiência
              </p>
            </div>
            <button
              onClick={() => handleGenerateTicket('priority')}
              disabled={isGenerating || !isConnected}
              className="w-full bg-amber-600 hover:bg-amber-700 text-white font-semibold py-4 px-6 rounded-xl transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? 'Gerando...' : 'Retirar Senha Prioritária'}
            </button>
          </div>
        </div>

        {lastTicket && (
          <div className="bg-white rounded-2xl p-8 shadow-lg text-center animate-fade-in">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <TicketIcon className="w-10 h-10 text-green-600" />
            </div>
            <h3 className="text-2xl font-semibold text-gray-800 mb-2">
              Senha Gerada com Sucesso!
            </h3>
            <div className="text-6xl font-bold text-gray-800 mb-4">
              {lastTicket.number}
            </div>
            <p className="text-lg text-gray-600 mb-2">
              Tipo: {lastTicket.type === 'priority' ? 'Prioritário' : 'Normal'}
            </p>
            <p className="text-sm text-gray-500">
              Gerada em: {lastTicket.createdAt.toLocaleTimeString()}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};