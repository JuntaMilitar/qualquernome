import React from 'react';
import { Settings, Play, CheckCircle, BarChart3, RefreshCw, WifiOff } from 'lucide-react';
import { Ticket, QueueStats } from '../types';

interface AdminPanelProps {
  currentTicket: Ticket | null;
  queueStats: QueueStats;
  onCallNext: () => void;
  onCompleteTicket: () => void;
  waitingTickets: Ticket[];
  isConnected: boolean;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  currentTicket,
  queueStats,
  onCallNext,
  onCompleteTicket,
  waitingTickets,
  isConnected,
}) => {
  const canCallNext = waitingTickets.length > 0 && isConnected;
  const canComplete = currentTicket !== null && isConnected;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <Settings className="w-8 h-8 text-purple-600" />
            <h1 className="text-3xl font-bold text-gray-800">
              Painel Administrativo
            </h1>
            {!isConnected && (
              <div className="flex items-center space-x-2 text-red-600">
                <WifiOff className="w-6 h-6" />
                <span className="text-sm">Desconectado</span>
              </div>
            )}
          </div>
          <div className="text-right">
            <div className="text-lg font-semibold text-gray-700">
              {new Date().toLocaleTimeString()}
            </div>
            <div className="text-sm text-gray-500">
              Sistema de Gerenciamento de Filas
            </div>
          </div>
        </div>

        {/* Connection Warning */}
        {!isConnected && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-6">
            <div className="flex items-center space-x-2">
              <WifiOff className="w-5 h-5" />
              <span>Sem conexão com o servidor. Funcionalidades limitadas.</span>
            </div>
          </div>
        )}

        {/* Current Ticket Status */}
        <div className="bg-white rounded-2xl p-8 shadow-lg mb-8">
          <h2 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
            <Play className="w-6 h-6 mr-2 text-purple-600" />
            Atendimento Atual
          </h2>
          
          {currentTicket ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-6">
                <div className="text-5xl font-bold text-purple-600">
                  {currentTicket.number}
                </div>
                <div>
                  <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                    currentTicket.type === 'priority'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-blue-100 text-blue-800'
                  }`}>
                    {currentTicket.type === 'priority' ? 'Prioritário' : 'Normal'}
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    Chamada às {currentTicket.calledAt?.toLocaleTimeString()}
                  </div>
                </div>
              </div>
              <button
                onClick={onCompleteTicket}
                disabled={!canComplete}
                className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-xl transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <CheckCircle className="w-5 h-5" />
                <span>Finalizar Atendimento</span>
              </button>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <div className="text-4xl font-semibold mb-2">
                Nenhum atendimento em andamento
              </div>
              <p>Chame a próxima senha para iniciar</p>
            </div>
          )}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Queue Controls */}
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h3 className="text-xl font-semibold text-gray-800 mb-6">
              Controles da Fila
            </h3>
            
            <div className="space-y-4">
              <button
                onClick={onCallNext}
                disabled={!canCallNext}
                className="w-full flex items-center justify-center space-x-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold py-4 px-6 rounded-xl transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <RefreshCw className="w-5 h-5" />
                <span>Chamar Próxima Senha</span>
              </button>
              
              <div className="grid grid-cols-2 gap-4 pt-4">
                <div className="bg-amber-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-amber-600">
                    {queueStats.priorityWaiting}
                  </div>
                  <div className="text-sm text-amber-700">
                    Prioritárias Aguardando
                  </div>
                </div>
                <div className="bg-blue-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {queueStats.normalWaiting}
                  </div>
                  <div className="text-sm text-blue-700">
                    Normais Aguardando
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Statistics */}
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h3 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
              <BarChart3 className="w-6 h-6 mr-2" />
              Estatísticas
            </h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-gray-800">
                  {queueStats.totalTickets}
                </div>
                <div className="text-sm text-gray-600">Total de Senhas</div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-gray-800">
                  {queueStats.waitingTickets}
                </div>
                <div className="text-sm text-gray-600">Em Espera</div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 text-center col-span-2">
                <div className="text-3xl font-bold text-gray-800">
                  {queueStats.averageWaitTime}min
                </div>
                <div className="text-sm text-gray-600">Tempo Médio de Espera</div>
              </div>
            </div>
          </div>
        </div>

        {/* Waiting Queue */}
        <div className="bg-white rounded-2xl p-8 shadow-lg mt-8">
          <h3 className="text-xl font-semibold text-gray-800 mb-6">
            Fila de Espera ({waitingTickets.length} senhas)
          </h3>
          
          {waitingTickets.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {waitingTickets.slice(0, 12).map((ticket, index) => (
                <div
                  key={ticket.id}
                  className={`p-4 rounded-lg border-2 ${
                    index === 0
                      ? 'border-yellow-400 bg-yellow-50'
                      : ticket.type === 'priority'
                      ? 'border-amber-200 bg-amber-50'
                      : 'border-blue-200 bg-blue-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="font-bold text-lg">
                      {ticket.number}
                    </div>
                    <div className={`px-2 py-1 rounded text-xs font-medium ${
                      ticket.type === 'priority'
                        ? 'bg-amber-200 text-amber-800'
                        : 'bg-blue-200 text-blue-800'
                    }`}>
                      {ticket.type === 'priority' ? 'P' : 'N'}
                    </div>
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    {ticket.createdAt.toLocaleTimeString()}
                  </div>
                  {index === 0 && (
                    <div className="text-xs text-yellow-600 font-medium mt-1">
                      Próxima
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>Nenhuma senha na fila de espera</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};