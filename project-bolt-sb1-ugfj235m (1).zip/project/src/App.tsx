import React, { useState } from 'react';
import { Monitor, Ticket, Settings, Wifi, WifiOff } from 'lucide-react';
import { useQueue } from './hooks/useQueue';
import { TicketGenerator } from './components/TicketGenerator';
import { Display } from './components/Display';
import { AdminPanel } from './components/AdminPanel';

type ViewMode = 'generator' | 'display' | 'admin';

function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('generator');
  const {
    tickets,
    currentTicket,
    addTicket,
    callNextTicket,
    completeCurrentTicket,
    getQueueStats,
    isConnected,
  } = useQueue();

  const waitingTickets = tickets.filter(t => t.status === 'waiting');
  const queueStats = getQueueStats();

  const renderView = () => {
    switch (viewMode) {
      case 'generator':
        return <TicketGenerator onGenerateTicket={addTicket} isConnected={isConnected} />;
      case 'display':
        return <Display currentTicket={currentTicket} waitingTickets={waitingTickets} isConnected={isConnected} />;
      case 'admin':
        return (
          <AdminPanel
            currentTicket={currentTicket}
            queueStats={queueStats}
            onCallNext={callNextTicket}
            onCompleteTicket={completeCurrentTicket}
            waitingTickets={waitingTickets}
            isConnected={isConnected}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="relative">
      {/* Navigation */}
      <div className="fixed top-4 left-4 z-50 bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg p-2">
        <div className="flex space-x-2">
          <button
            onClick={() => setViewMode('generator')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-colors duration-200 ${
              viewMode === 'generator'
                ? 'bg-blue-600 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Ticket className="w-4 h-4" />
            <span className="hidden sm:inline">Gerador</span>
          </button>
          <button
            onClick={() => setViewMode('display')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-colors duration-200 ${
              viewMode === 'display'
                ? 'bg-blue-600 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Monitor className="w-4 h-4" />
            <span className="hidden sm:inline">Display</span>
          </button>
          <button
            onClick={() => setViewMode('admin')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-colors duration-200 ${
              viewMode === 'admin'
                ? 'bg-blue-600 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span className="hidden sm:inline">Admin</span>
          </button>
        </div>
      </div>

      {/* Connection Status & Queue Status */}
      <div className="fixed top-4 right-4 z-50 bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg p-4">
        <div className="flex items-center space-x-4 text-sm">
          {/* Connection Status */}
          <div className={`flex items-center space-x-2 ${isConnected ? 'text-green-600' : 'text-red-600'}`}>
            {isConnected ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
            <span className="hidden sm:inline">{isConnected ? 'Conectado' : 'Desconectado'}</span>
          </div>
          
          {/* Queue Stats */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
              <span>{queueStats.priorityWaiting}P</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span>{queueStats.normalWaiting}N</span>
            </div>
            {currentTicket && (
              <div className="flex items-center space-x-2 text-green-600 font-medium">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                <span>{currentTicket.number}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Offline Warning */}
      {!isConnected && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg shadow-lg">
          <div className="flex items-center space-x-2">
            <WifiOff className="w-5 h-5" />
            <span>Sem conexão com o servidor. Verifique se o servidor está rodando.</span>
          </div>
        </div>
      )}

      {renderView()}
    </div>
  );
}

export default App;