import { useState, useEffect, useCallback } from 'react';
import { Ticket, QueueStats } from '../types';

const API_BASE = 'http://localhost:3001/api';

export const useQueue = () => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [currentTicket, setCurrentTicket] = useState<Ticket | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  // WebSocket connection
  useEffect(() => {
    const ws = new WebSocket('ws://localhost:3001');
    
    ws.onopen = () => {
      console.log('Conectado ao servidor');
      setIsConnected(true);
    };
    
    ws.onclose = () => {
      console.log('Desconectado do servidor');
      setIsConnected(false);
    };
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'TICKET_CREATED':
          setTickets(prev => [...prev, {
            ...data.ticket,
            createdAt: new Date(data.ticket.createdAt)
          }]);
          break;
          
        case 'TICKET_CALLED':
          setTickets(prev => prev.map(t => 
            t.id === data.ticket.id 
              ? { ...data.ticket, createdAt: new Date(data.ticket.createdAt), calledAt: new Date(data.ticket.calledAt) }
              : t
          ));
          setCurrentTicket({
            ...data.ticket,
            createdAt: new Date(data.ticket.createdAt),
            calledAt: new Date(data.ticket.calledAt)
          });
          break;
          
        case 'TICKET_COMPLETED':
          setTickets(prev => prev.map(t => 
            t.id === data.ticketId 
              ? { ...t, status: 'completed' as const }
              : t
          ));
          setCurrentTicket(null);
          break;
      }
    };
    
    return () => {
      ws.close();
    };
  }, []);

  // Load initial data
  useEffect(() => {
    const loadData = async () => {
      try {
        // Load tickets
        const ticketsResponse = await fetch(`${API_BASE}/tickets`);
        const ticketsData = await ticketsResponse.json();
        
        setTickets(ticketsData.map((ticket: any) => ({
          ...ticket,
          createdAt: new Date(ticket.createdAt),
          calledAt: ticket.calledAt ? new Date(ticket.calledAt) : undefined
        })));
        
        // Load current ticket
        const currentResponse = await fetch(`${API_BASE}/tickets/current`);
        const currentData = await currentResponse.json();
        
        if (currentData) {
          setCurrentTicket({
            ...currentData,
            createdAt: new Date(currentData.createdAt),
            calledAt: currentData.calledAt ? new Date(currentData.calledAt) : undefined
          });
        }
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
      }
    };
    
    loadData();
  }, []);

  const addTicket = useCallback(async (type: 'normal' | 'priority') => {
    try {
      const response = await fetch(`${API_BASE}/tickets`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ type }),
      });
      
      const ticket = await response.json();
      return {
        ...ticket,
        createdAt: new Date(ticket.createdAt)
      };
    } catch (error) {
      console.error('Erro ao gerar senha:', error);
      throw error;
    }
  }, []);

  const callNextTicket = useCallback(async () => {
    try {
      await fetch(`${API_BASE}/tickets/call-next`, {
        method: 'POST',
      });
    } catch (error) {
      console.error('Erro ao chamar próxima senha:', error);
    }
  }, []);

  const completeCurrentTicket = useCallback(async () => {
    if (!currentTicket) return;
    
    try {
      await fetch(`${API_BASE}/tickets/${currentTicket.id}/complete`, {
        method: 'POST',
      });
    } catch (error) {
      console.error('Erro ao finalizar atendimento:', error);
    }
  }, [currentTicket]);

  const getQueueStats = useCallback((): QueueStats => {
    const waiting = tickets.filter(t => t.status === 'waiting');
    const completed = tickets.filter(t => t.status === 'completed');
    
    const averageWaitTime = completed.length > 0
      ? completed.reduce((acc, ticket) => {
          if (ticket.calledAt) {
            return acc + (ticket.calledAt.getTime() - ticket.createdAt.getTime());
          }
          return acc;
        }, 0) / completed.length / 1000 / 60
      : 0;

    return {
      totalTickets: tickets.length,
      waitingTickets: waiting.length,
      priorityWaiting: waiting.filter(t => t.type === 'priority').length,
      normalWaiting: waiting.filter(t => t.type === 'normal').length,
      averageWaitTime: Math.round(averageWaitTime),
    };
  }, [tickets]);

  return {
    tickets,
    currentTicket,
    addTicket,
    callNextTicket,
    completeCurrentTicket,
    getQueueStats,
    isConnected,
  };
};