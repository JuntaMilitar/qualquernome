export interface Ticket {
  id: string;
  number: string;
  type: 'normal' | 'priority';
  status: 'waiting' | 'called' | 'completed';
  createdAt: Date;
  calledAt?: Date;
}

export interface QueueStats {
  totalTickets: number;
  waitingTickets: number;
  priorityWaiting: number;
  normalWaiting: number;
  averageWaitTime: number;
}