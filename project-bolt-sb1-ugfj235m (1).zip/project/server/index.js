import express from 'express';
import sqlite3 from 'sqlite3';
import cors from 'cors';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3001;

// Configuração do banco de dados
const db = new sqlite3.Database('./queue.db');

// Criar tabelas
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS tickets (
    id TEXT PRIMARY KEY,
    number TEXT NOT NULL,
    type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'waiting',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    called_at DATETIME
  )`);
  
  db.run(`CREATE TABLE IF NOT EXISTS counters (
    type TEXT PRIMARY KEY,
    count INTEGER DEFAULT 0
  )`);
  
  // Inicializar contadores
  db.run("INSERT OR IGNORE INTO counters (type, count) VALUES ('normal', 0)");
  db.run("INSERT OR IGNORE INTO counters (type, count) VALUES ('priority', 0)");
});

app.use(cors());
app.use(express.json());

// Criar servidor HTTP para WebSocket
const server = createServer(app);
const wss = new WebSocketServer({ server });

// Broadcast para todos os clientes conectados
function broadcast(data) {
  wss.clients.forEach(client => {
    if (client.readyState === 1) { // WebSocket.OPEN
      client.send(JSON.stringify(data));
    }
  });
}

// WebSocket connection
wss.on('connection', (ws) => {
  console.log('Cliente conectado via WebSocket');
  
  ws.on('close', () => {
    console.log('Cliente desconectado');
  });
});

// API Routes

// Gerar nova senha
app.post('/api/tickets', (req, res) => {
  const { type } = req.body;
  
  if (!['normal', 'priority'].includes(type)) {
    return res.status(400).json({ error: 'Tipo inválido' });
  }
  
  db.get("SELECT count FROM counters WHERE type = ?", [type], (err, row) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    const newCount = (row?.count || 0) + 1;
    const prefix = type === 'priority' ? 'P' : 'N';
    const number = `${prefix}${newCount.toString().padStart(3, '0')}`;
    const id = crypto.randomUUID();
    
    // Atualizar contador
    db.run("UPDATE counters SET count = ? WHERE type = ?", [newCount, type], (err) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      // Inserir ticket
      db.run(
        "INSERT INTO tickets (id, number, type, status, created_at) VALUES (?, ?, ?, 'waiting', datetime('now'))",
        [id, number, type],
        function(err) {
          if (err) {
            return res.status(500).json({ error: err.message });
          }
          
          const ticket = {
            id,
            number,
            type,
            status: 'waiting',
            createdAt: new Date().toISOString()
          };
          
          // Broadcast para todos os clientes
          broadcast({ type: 'TICKET_CREATED', ticket });
          
          res.json(ticket);
        }
      );
    });
  });
});

// Obter todos os tickets
app.get('/api/tickets', (req, res) => {
  db.all(
    "SELECT * FROM tickets ORDER BY created_at ASC",
    [],
    (err, rows) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      const tickets = rows.map(row => ({
        id: row.id,
        number: row.number,
        type: row.type,
        status: row.status,
        createdAt: row.created_at,
        calledAt: row.called_at
      }));
      
      res.json(tickets);
    }
  );
});

// Chamar próxima senha
app.post('/api/tickets/call-next', (req, res) => {
  // Buscar próximo ticket (prioridade primeiro)
  db.get(`
    SELECT * FROM tickets 
    WHERE status = 'waiting' 
    ORDER BY 
      CASE WHEN type = 'priority' THEN 0 ELSE 1 END,
      created_at ASC 
    LIMIT 1
  `, [], (err, row) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    if (!row) {
      return res.status(404).json({ error: 'Nenhuma senha na fila' });
    }
    
    // Atualizar status para 'called'
    db.run(
      "UPDATE tickets SET status = 'called', called_at = datetime('now') WHERE id = ?",
      [row.id],
      function(err) {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        
        const ticket = {
          id: row.id,
          number: row.number,
          type: row.type,
          status: 'called',
          createdAt: row.created_at,
          calledAt: new Date().toISOString()
        };
        
        // Broadcast para todos os clientes
        broadcast({ type: 'TICKET_CALLED', ticket });
        
        res.json(ticket);
      }
    );
  });
});

// Finalizar atendimento
app.post('/api/tickets/:id/complete', (req, res) => {
  const { id } = req.params;
  
  db.run(
    "UPDATE tickets SET status = 'completed' WHERE id = ?",
    [id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      if (this.changes === 0) {
        return res.status(404).json({ error: 'Ticket não encontrado' });
      }
      
      // Broadcast para todos os clientes
      broadcast({ type: 'TICKET_COMPLETED', ticketId: id });
      
      res.json({ success: true });
    }
  );
});

// Obter ticket atual (sendo atendido)
app.get('/api/tickets/current', (req, res) => {
  db.get(
    "SELECT * FROM tickets WHERE status = 'called' ORDER BY called_at DESC LIMIT 1",
    [],
    (err, row) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      if (!row) {
        return res.json(null);
      }
      
      const ticket = {
        id: row.id,
        number: row.number,
        type: row.type,
        status: row.status,
        createdAt: row.created_at,
        calledAt: row.called_at
      };
      
      res.json(ticket);
    }
  );
});

// Estatísticas
app.get('/api/stats', (req, res) => {
  db.all(`
    SELECT 
      COUNT(*) as total,
      SUM(CASE WHEN status = 'waiting' THEN 1 ELSE 0 END) as waiting,
      SUM(CASE WHEN status = 'waiting' AND type = 'priority' THEN 1 ELSE 0 END) as priority_waiting,
      SUM(CASE WHEN status = 'waiting' AND type = 'normal' THEN 1 ELSE 0 END) as normal_waiting,
      SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
    FROM tickets
  `, [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    const stats = rows[0];
    res.json({
      totalTickets: stats.total || 0,
      waitingTickets: stats.waiting || 0,
      priorityWaiting: stats.priority_waiting || 0,
      normalWaiting: stats.normal_waiting || 0,
      averageWaitTime: 0 // Implementar cálculo se necessário
    });
  });
});

server.listen(port, '0.0.0.0', () => {
  console.log(`🚀 Servidor rodando em http://localhost:${port}`);
  console.log(`📡 WebSocket disponível em ws://localhost:${port}`);
  console.log(`🌐 Acesso na rede: http://[SEU-IP]:${port}`);
});