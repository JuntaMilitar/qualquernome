# Sistema de Gerenciamento de Filas

Sistema completo de gerenciamento de filas com suporte a múltiplos computadores, desenvolvido com React + TypeScript no frontend e Node.js + Express + SQLite no backend.

## 🚀 Funcionalidades

- **Geração de Senhas**: Normal e Prioritária
- **Display em Tempo Real**: Mostra a senha atual e próximas senhas
- **Painel Administrativo**: Controle completo da fila
- **Multi-dispositivo**: Suporte a múltiplos computadores na mesma rede
- **Sincronização em Tempo Real**: WebSocket para atualizações instantâneas
- **Interface Responsiva**: Funciona em desktop, tablet e mobile

## 🛠️ Tecnologias

### Frontend
- React 18 + TypeScript
- Tailwind CSS
- Lucide React (ícones)
- WebSocket para tempo real

### Backend
- Node.js + Express
- SQLite (banco de dados)
- WebSocket Server
- CORS habilitado

## 📦 Instalação

1. **Clone ou baixe o projeto**

2. **Instale as dependências**:
```bash
npm install
```

3. **Inicie o sistema completo**:
```bash
npm run dev:full
```

Ou inicie separadamente:

**Backend** (Terminal 1):
```bash
npm run server
```

**Frontend** (Terminal 2):
```bash
npm run dev
```

## 🌐 Acesso Multi-computador

### 1. Descubra o IP do servidor

**Windows**:
```cmd
ipconfig
```

**Mac/Linux**:
```bash
ifconfig
```

Procure pelo endereço IPv4 (ex: 192.168.1.100)

### 2. Configure o acesso na rede

No arquivo `src/hooks/useQueue.ts`, altere as URLs para usar o IP do servidor:

```typescript
const API_BASE = 'http://[SEU-IP]:3001/api';
// WebSocket: 'ws://[SEU-IP]:3001'
```

### 3. Acesse de outros computadores

- **Frontend**: `http://[SEU-IP]:5173`
- **API**: `http://[SEU-IP]:3001`

### 4. Libere as portas no firewall

**Windows**:
- Firewall do Windows → Permitir aplicativo → Adicionar portas 3001 e 5173

**Mac**:
```bash
sudo /usr/libexec/ApplicationFirewall/socketfilterfw --addport=3001/tcp
sudo /usr/libexec/ApplicationFirewall/socketfilterfw --addport=5173/tcp
```

## 📱 Como Usar

### Gerador de Senhas
- Acesse a aba "Gerador"
- Clique em "Senha Normal" ou "Senha Prioritária"
- A senha será gerada e exibida

### Display
- Acesse a aba "Display"
- Mostra a senha atual sendo atendida
- Lista as próximas senhas na fila
- Atualiza automaticamente em tempo real

### Painel Admin
- Acesse a aba "Admin"
- Clique em "Chamar Próxima Senha" para chamar
- Clique em "Finalizar Atendimento" para completar
- Visualize estatísticas e fila de espera

## 🔧 Configuração de Rede

### Modelo de Uso Ideal

1. **Computador Servidor**:
   - Executa `npm run dev:full`
   - Pode ser usado como admin

2. **Computador Gerador** (Recepção):
   - Acessa `http://[IP-SERVIDOR]:5173`
   - Aba "Gerador" para emitir senhas

3. **Computador Display** (Painel):
   - Acessa `http://[IP-SERVIDOR]:5173`
   - Aba "Display" para mostrar senhas

4. **Computador Admin** (Atendimento):
   - Acessa `http://[IP-SERVIDOR]:5173`
   - Aba "Admin" para controlar a fila

## 📊 API Endpoints

- `POST /api/tickets` - Gerar nova senha
- `GET /api/tickets` - Listar todas as senhas
- `POST /api/tickets/call-next` - Chamar próxima senha
- `POST /api/tickets/:id/complete` - Finalizar atendimento
- `GET /api/tickets/current` - Senha atual
- `GET /api/stats` - Estatísticas da fila

## 🔄 WebSocket Events

- `TICKET_CREATED` - Nova senha gerada
- `TICKET_CALLED` - Senha chamada
- `TICKET_COMPLETED` - Atendimento finalizado

## 🗃️ Banco de Dados

O sistema usa SQLite com as seguintes tabelas:

- `tickets` - Armazena todas as senhas
- `counters` - Controla numeração sequencial

O arquivo `queue.db` é criado automaticamente na primeira execução.

## 🚨 Solução de Problemas

### Conexão Recusada
- Verifique se ambos computadores estão na mesma rede
- Confirme se o firewall permite as conexões
- Teste o acesso direto: `http://[IP]:3001/api/stats`

### WebSocket não conecta
- Verifique se a porta 3001 está liberada
- Confirme se o servidor está rodando
- Teste a conexão WebSocket

### Interface não atualiza
- Verifique a conexão WebSocket no console do navegador
- Confirme se o servidor está enviando eventos
- Recarregue a página se necessário

## 📝 Logs

O servidor exibe logs importantes:
- Conexões WebSocket
- Geração de senhas
- Chamadas de senhas
- Erros de banco de dados

Monitore o terminal onde o servidor está rodando para debug.